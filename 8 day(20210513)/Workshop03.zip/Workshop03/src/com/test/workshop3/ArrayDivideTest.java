package com.test.workshop3;

public class ArrayDivideTest {
    
    public static void main( String[] args ) {
        
        int[] arrayOne = { 10, 20, 13, 25 };
        int[] arrayTwo = { 2, 5, 0, 3, 1, 7 };
        
        //TODO ���α׷� �ۼ�
    }
}