package com.test.workshop3.exception;

public class InvalidValueException extends Exception {
    public InvalidValueException(String msg) {
        super(msg);
    }
}